import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, SetEnvironmentVariable
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    TimerAction,
)


def generate_launch_description():

    # Percorsi ai file
    xacro_file_name = "fra2mo.urdf.xacro"
    xacro = os.path.join(get_package_share_directory('rl_fra2mo_description'), "urdf", xacro_file_name)

    models_path = os.path.join(get_package_share_directory('rl_fra2mo_description'), 'models')
    world_file = os.path.join(get_package_share_directory('rl_fra2mo_description'), "worlds", "leonardo_race_field.sdf")

    # Genera la descrizione del robot usando xacro
    robot_description_xacro = {"robot_description": ParameterValue(Command(['xacro ', xacro]),value_type=str)}
    
    # use_sim_time_arg = DeclareLaunchArgument(
    #     'use_sim_time', default_value='true', description='Use simulation/Gazebo clock')

    # Nodo robot_state_publisher
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[robot_description_xacro,
                    {"use_sim_time": True}
            ]
    )
    
    # # Nodo joint_state_publisher
    joint_state_publisher_node = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        parameters=[{"use_sim_time": True}]
    )

    declared_arguments = []
    declared_arguments.append(DeclareLaunchArgument('gz_args', default_value='-r -v 1 ' + world_file,
                              description='path to world file'),)
    
    # Gazebo simulation launch description
    gazebo_ignition = IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                [PathJoinSubstitution([FindPackageShare('ros_gz_sim'),
                                    'launch',
                                    'gz_sim.launch.py'])]),
            launch_arguments={'gz_args': LaunchConfiguration('gz_args')}.items()
    )

    position = [0.0, 0.0, 0.100]

    # Define a Node to spawn the robot in the Gazebo simulation
    gz_spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        output='screen',
        arguments=['-topic', 'robot_description',
                   '-name', 'fra2mo',
                   '-allow_renaming', 'true',
                    "-x", str(position[0]),
                    "-y", str(position[1]),
                    "-z", str(position[2]),]
    )

    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/cmd_vel@geometry_msgs/msg/Twist@ignition.msgs.Twist',
                   '/model/fra2mo/odometry@nav_msgs/msg/Odometry@ignition.msgs.Odometry',
                   '/model/fra2mo/tf@tf2_msgs/msg/TFMessage@ignition.msgs.Pose_V',
                   '/lidar@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
                   '/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock',
                   '/camera/image_raw@sensor_msgs/msg/Image[ignition.msgs.Image',  # Immagine RGB
                   '/camera/camera_info@sensor_msgs/msg/CameraInfo[ignition.msgs.CameraInfo',  # Info fotocamera
                   '/camera/depth/image_raw@sensor_msgs/msg/Image[ignition.msgs.Image',  # Immagine profondità
                   '/camera/depth/camera_info@sensor_msgs/msg/CameraInfo[ignition.msgs.CameraInfo'],  # Info fotocamera profondità
                   #'/camera/points@sensor_msgs/msg/PointCloud2[ignition.msgs.PointCloudPacked',  # Nuvola di punti (se necessario)
                   #'/lidar/points@sensor_msgs/msg/PointCloud2[ignition.msgs.PointCloudPacked'], 
        output='screen'
    )

    odom_tf = Node(
        package='rl_fra2mo_description',
        executable='dynamic_tf_publisher',
        name='odom_tf',
        parameters=[{"use_sim_time": True}]
    )

    laser_id_link_tf = Node(package='tf2_ros',
                     executable='static_transform_publisher',
                     name='lidar_staticTF',
                     output='log',
                     arguments=['0.0', '0.0', '0.0', '0.0', '0.0', '0.0', 'laser_frame', 'fra2mo/base_footprint/laser_frame'],
                     parameters=[{"use_sim_time": True}]
    )

    robot_localization_node = Node(
       package='robot_localization',
       executable='ekf_node',
       name='ekf_filter_node',
       output='screen',
       parameters=[os.path.join(get_package_share_directory('rl_fra2mo_description'), "config/ekf.yaml")]
    )

    ign_clock_bridge = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        name="ros_gz_bridge",
        arguments=["/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock"],
        remappings=[
            ("/tf", "tf"),
            ("/tf_static", "tf_static"),
        ],
        output="screen",
        namespace="fra2mo"
    )
 


    parameters_rgbd=[{
    # 'frame_id':'camera_link',
    'frame_id':'base_link',
    'odom_frame_id':'odom',
    'use_sim_time':True,
    'subscribe_depth':True,
    'subscribe_odom_info':True,
    'approx_sync':True,

    'publish_null_when_lost': False,

    'publish_tf': True,                    
    'Vis/MinInliers' : '5',
    'Odometer/MinInliers': 5,  # Riduce la soglia minima per gli inliers
    'Odometer/MaxUpdateError': 0.5,  # Aumenta l'errore massimo per l'aggiornamento (più basso  -> più preciso)
    'Odometer/UpdateMaxFeatures': 200,  # Aumenta il numero massimo di feature usate per l'aggiornamento
    'Odometer/Reset': True,  # Abilita il reset automatico dell'odometria in caso di errore
    'publish_null_when_lost': False,    # non pubblica /odom se non riceve feature 


    
    }]

    # use color camera 
    remappings_rgbd=[
        #('imu', '/imu/data'),
        ('rgb/image', '/camera/image_raw'),
        ('rgb/camera_info', '/camera/camera_info'),
        ('depth/image', '/camera/depth/image_raw')] 

    rtabmap_camera_node = TimerAction (
        period=3.0,
        actions=[Node(
            package='rtabmap_odom', executable='rgbd_odometry', output='screen',
            parameters=parameters_rgbd,
            remappings=remappings_rgbd),
        ]
    )


    parameters_icp=[{
        'frame_id':'base_link',
        'subscribe_depth':True,
        'subscribe_scan_cloud':False, 
        'scan_cloud_max_points': 5000,  # Puoi aumentare questo valore se vuoi più punti per il rilevamento
        'scan_range_max': 5.0,   # 10 metri come distanza massima di rilevamento
        'scan_range_min': 0.05,   # Permette di rilevare oggetti a 10 cm di distanza o più
        'subscribe_scan':True,         
        'subscribe_rgbd':False,
        'subscribe_rgb':True,
        'approx_sync':True,  
        'use_sim_time':True,
        'publish_tf':True,
        'odom_frame_id':'odom',
        'odom_topic':'odom',
        'queue_size': 10,  
        'map_always_update': True, 
        'map_empty_ray_tracing': True,

        'guess_min_translation': 0.1,  # Aumentato a 10 cm
        'guess_min_rotation': 0.1,     # Aumentato a 0.1 rad

         'publish_null_when_lost': False,
         'Odom/ResetCountdown': '1', #You can set Odom/ResetCountdown parameter to 1 to force an automatic reset of odometry from latest pose.
          }]

    remappings_icp=[
        ('rgb/image', '/camera/image_raw'),
        ('rgb/camera_info', '/camera/camera_info'),
        ('depth/image', '/camera/depth/image_raw'),
        ('scan', '/lidar' )]

    rtabmap_lidar_node = TimerAction (
        period=3.0,
        actions=[Node(
            package='rtabmap_odom', executable='icp_odometry', output='screen',
            parameters=parameters_icp,
            #node_namespace='rtabmap',
            #arguments=['-d  --uinfo ' ], #--uinfo --Icp/Strategy 0
            remappings=remappings_icp),
        ]
        )


    ign = [gazebo_ignition, gz_spawn_entity]
    nodes_to_start = [robot_state_publisher_node, #joint_state_publisher_node,
                     *ign, bridge, 
                     #rtabmap_camera_node,
                      #odom_tf, 
                      #laser_id_link_tf, 
                      #ign_clock_bridge,
                      rtabmap_lidar_node,
                      #robot_localization_node,
                      ]


    return LaunchDescription([SetEnvironmentVariable(name="GZ_SIM_RESOURCE_PATH", value = models_path + ':' + os.environ.get('GZ_SIM_RESOURCE_PATH', ''))] + declared_arguments + nodes_to_start)
