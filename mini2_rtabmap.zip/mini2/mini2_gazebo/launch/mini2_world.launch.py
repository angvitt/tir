
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, RegisterEventHandler, SetEnvironmentVariable, TimerAction
from launch.conditions import IfCondition, UnlessCondition
from launch.event_handlers import OnProcessExit, OnProcessStart
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, FindExecutable, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory
from ament_index_python import get_package_prefix
import os


def generate_launch_description():
    declared_arguments = []
   

    link_description_path = get_package_share_directory('mini2_description')

    desc_path = os.path.join(link_description_path, "urdf", "mini2_description.urdf")
    desc_path_xacro=os.path.join(link_description_path, "urdf", "mini2.urdf.xacro")

    with open(desc_path, 'r') as infp:
        robot_description_content = infp.read()


    robot_description = {'robot_description': robot_description_content}
    r_d_x = {"robot_description":Command(['xacro ', desc_path_xacro])}

   
    robot_state_pub_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        
        output='both',
        parameters=[r_d_x,
                    {"use_sim_time": True},
                    ],
    )
   
    models_path = os.path.join(get_package_share_directory('mini2_description'), 'models')
    
    world_file = os.path.join(get_package_share_directory('mini2_description'), "worlds", "empty_custom.sdf")


    declared_arguments.append(DeclareLaunchArgument('gz_args', default_value='-r -v 1 ' + world_file,
                               description='Arguments for gz_sim'),)

    #declared_arguments.append(DeclareLaunchArgument('gz_args', default_value='-r -v 1 empty.sdf',
    #                          description='Arguments for gz_sim'),)
    
    gazebo_ignition = IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                [PathJoinSubstitution([FindPackageShare('ros_gz_sim'),
                                    'launch',
                                    'gz_sim.launch.py'])]),
            launch_arguments={'gz_args': LaunchConfiguration('gz_args')}.items()
    )


    gz_spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        output='screen',
        arguments=['-topic', 'robot_description',
                   '-name', 'mini2',
                   '-allow_renaming', 'true',],
    )
 
    ign = [gazebo_ignition, gz_spawn_entity]


    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/lidar@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
                   
                   '/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock',

                   '/imu@sensor_msgs/msg/Imu[ignition.msgs.IMU',

                   '/cmd_vel@geometry_msgs/msg/Twist@ignition.msgs.Twist',
                   '/camera/image_raw@sensor_msgs/msg/Image[ignition.msgs.Image',  # Immagine RGB
                   '/camera/camera_info@sensor_msgs/msg/CameraInfo[ignition.msgs.CameraInfo',  # Info fotocamera
                   '/camera/depth/image_raw@sensor_msgs/msg/Image[ignition.msgs.Image',  # Immagine profondità
                   '/camera/depth/camera_info@sensor_msgs/msg/CameraInfo[ignition.msgs.CameraInfo',  # Info fotocamera profondità
                   '/camera/points@sensor_msgs/msg/PointCloud2[ignition.msgs.PointCloudPacked',  # Nuvola di punti (se necessario)
                   #'/depth/image_raw/points@sensor_msgs/msg/PointCloud2[ignition.msgs.PointCloudPacked',
               

                #    '/model/mini2/odometry@nav_msgs/msg/Odometry@ignition.msgs.Odometry',
                #    '/model/mini2/tf@tf2_msgs/msg/TFMessage@ignition.msgs.Pose_V',

                   #'/camera@sensor_msgs/msg/Image@ignition.msgs.Image', 
                   #'/camera_info@sensor_msgs/msg/CameraInfo@ignition.msgs.CameraInfo',
                   #'/depth_camera/points@sensor_msgs/msg/PointCloud2@gz.msgs.PointCloudPacked',
                   #'/depth_camera@sensor_msgs/msg/Image@ignition.msgs.Image',
                #    '/depth_camera/image_raw@sensor_msgs/msg/Image@ignition.msgs.Image',
                #    '/depth_camera/camera_info@sensor_msgs/msg/CameraInfo@ignition.msgs.CameraInfo',
                #    '/depth/points@sensor_msgs/msg/PointCloud2@ignition.msgs.PointCloudPacked'
                   ],
                   #'/lidar/points@sensor_msgs/msg/PointCloud2[ignition.msgs.PointCloudPacked'], 
        output='screen'
    )

    laser_id_link_tf = Node(package='tf2_ros',
                     executable='static_transform_publisher',
                     name='lidar_staticTF',
                     output='log',
                     arguments=['0.0', '0.0', '0.0', '0.0', '0.0', '0.0', 'laser_frame', 'mini2/base_footprint/laser_frame'],
                     parameters=[{"use_sim_time": True}]
    )
    
    # Fixing the odometry frame in the map
    odom_tf = Node(
        package='mini2_gazebo',
        executable='dynamic_tf_publisher',
        name='odom_tf'
        )
    
    robot_localization_node = Node(
       package='robot_localization',
       executable='ekf_node',
       name='ekf_filter_node',
       output='screen',
       parameters=[os.path.join(get_package_share_directory('mini2_description'), "config/ekf.yaml")]
    )


    parameterss=[{
    # 'frame_id':'camera_link',
    'frame_id':'base_link',
    'odom_frame_id':'odom',
    'use_sim_time':True,
    'subscribe_depth':True,
    'subscribe_odom_info':True,
    'approx_sync':True,
    #'qos_image':qos,
    #'qos_imu':qos,
    #'wait_imu_to_init':False
    #'wait_for_transform' : True,
    #'wait_for_transform_duration' : 0.200000,
    #'publish_tf' : True,
    #'Odom/ResetCountdown' : 1,
    # 'Odometer/MinInliers' : 0,
    # 'Odometer/MaxUpdateError': 0.5,
    # 'Odometer/UpdateMaxFeatures': 100,
    #'Odometer/Reset': False,
    'publish_null_when_lost': False,
    #'wait_for_transform' : False,
    'publish_tf': True,                    # Pubblica il TF dal /odom a /base_link
    #'publish_null_when_lost': False,       # Non pubblica un "null transform", mantieni l'odometria corrente
    #'guess_frame_id': 'odom',   # Usa il frame "odom_combined" come punto di riferimento per l'odometria
    #'guess_min_translation': 0.01,        # Imposta una piccola soglia per la traslazione (1 cm)
    #'guess_min_rotation': 0.01,           # Imposta una piccola soglia per la rotazione (0.01 rad)
    #'wait_for_transform': False,          # Non aspettare per il TF, continua con l'odometria disponibile

    }]

    # use color camera 
    remappingss=[
        #('imu', '/imu/data'),
        ('rgb/image', '/camera/image_raw'),
        ('rgb/camera_info', '/camera/camera_info'),
        ('depth/image', '/camera/depth/image_raw')] 

    rtabmap_node = TimerAction (
        period=2.0,
        actions=[Node(
            package='rtabmap_odom', executable='rgbd_odometry', output='screen',
            parameters=parameterss,
            remappings=remappingss),
        ]
    )


    parameters_icp=[{
        'frame_id':'base_link',
        'subscribe_depth':True,
        'subscribe_scan_cloud':False, 
        'scan_cloud_max_points': 500,
        'scan_range_max': 3.0,
        'scan_range_min': 0.2,
        'subscribe_scan':True,         
        'subscribe_rgbd':False,
        'subscribe_rgb':True,
        'approx_sync':True,
        'use_sim_time':True,
        'publish_tf':True,
        'odom_frame_id':'odom',
        'odom_topic':'odom',
        'queue_size': 3,
        'map_always_update': True,
        'map_empty_ray_tracing': True,
          }]

    remappings=[
        ('rgb/image', '/camera/image_raw'),
        ('rgb/camera_info', '/camera/camera_info'),
        ('depth/image', '/camera/depth/image_raw'),
        ('scan', '/lidar' )]

    rtabmap_lidar_node = TimerAction (
        period=2.0,
        actions=[Node(
            package='rtabmap_odom', executable='icp_odometry', output='screen',
            parameters=parameters_icp,
            #node_namespace='rtabmap',
            #arguments=['-d  --uinfo ' ], #--uinfo --Icp/Strategy 0
            remappings=remappings),
        ]
        )

# per fare ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 camera_link mini2/worldd/rgb_camera
    tf_camera = Node(
            package='tf2_ros',  
            executable='static_transform_publisher', 
            name='camera_staticTF', 
            output='log',  
            arguments=['0.0', '0.0', '0.0', '0.0', '0.0', '0.0', 'camera_link', 'mini2/worldd/rgb_camera'],  
            parameters=[{"use_sim_time": True}],
        ),

    rtabmap_rviz = TimerAction (
        period=2.0,
        actions=[Node(
            package='rtabmap_viz', executable='rtabmap_viz', output='screen',
            parameters=parameterss,
            remappings=remappingss),
        ]
    )

    nodes = [
        robot_state_pub_node,
        *ign,
        bridge,
        #laser_id_link_tf,
        #odom_tf,
        #robot_localization_node
        #rtabmap_node,
        #tf_camera,
        #rtabmap_rviz,
        #rtabmap_lidar_node,

    ]

   # Set the environment variable before returning
    set_env_var = SetEnvironmentVariable(name="GZ_SIM_RESOURCE_PATH", value=models_path + ':' + os.environ.get('GZ_SIM_RESOURCE_PATH', ''))

    #return LaunchDescription([set_env_var] + declared_arguments + nodes)

    return LaunchDescription(declared_arguments + nodes)