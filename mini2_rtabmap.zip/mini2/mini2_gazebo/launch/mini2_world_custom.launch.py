from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare
from launch.launch_description_sources import PythonLaunchDescriptionSource
import os

def generate_launch_description():
    # Percorso del mondo personalizzato 'leonardo_race_field.sdf'
    mini2_path = FindPackageShare('mini2_description').find('mini2_description')
    world_file = os.path.join(mini2_path, 'worlds', 'leonardo_race_field.sdf')

    # Percorso dei modelli di Gazebo (se necessario)
    models_path = os.path.join(mini2_path, 'models')

    # Dichiarazione dell'argomento per passare il mondo da caricare
    declared_arguments = []
    declared_arguments.append(DeclareLaunchArgument('gz_args', default_value=world_file,
                                                  description='Arguments for gz_sim (path to world file)'))

    # Impostazione della variabile d'ambiente per i modelli di Gazebo
    set_env_var = SetEnvironmentVariable(
        name="GZ_SIM_RESOURCE_PATH",
        value=models_path + ':' + os.environ.get('GZ_SIM_RESOURCE_PATH', '')
    )

    # Includi il lancio di Gazebo con il mondo personalizzato
    gazebo_ignition = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [PathJoinSubstitution([FindPackageShare('ros_gz_sim'),
                                    'launch',
                                    'gz_sim.launch.py'])]),
        launch_arguments={'gz_args': LaunchConfiguration('gz_args')}.items()
    )

    # Ritorna la descrizione di lancio con la variabile d'ambiente e il lancio del mondo
    return LaunchDescription([set_env_var] + declared_arguments + [gazebo_ignition])
