
from launch import LaunchDescription
from launch.actions import  TimerAction
from launch_ros.actions import Node

import os


def generate_launch_description():

   
    # Fixing the odometry frame in the map
    odom_tf = Node(
        package='mini2_gazebo',
        executable='dynamic_tf_publisher',
        name='odom_tf'
        )
    

    parameters_rgbd=[{
    # 'frame_id':'camera_link',
    'frame_id':'base_link',
    'odom_frame_id':'odom',
    'odom_topic':'odom_camera',     # nome topic /odom -> /odom_camera
    'use_sim_time':True,
    'subscribe_depth':True,
    'subscribe_odom_info':True,
    'approx_sync':True,
    #'qos_image':qos,
    #'qos_imu':qos,
    #'wait_imu_to_init':False
    #'wait_for_transform' : True,
    #'wait_for_transform_duration' : 0.200000,
    #'publish_tf' : True,
    #'Odom/ResetCountdown' : 1,
    'Vis/MinInliers' : '5',
    'Odometer/MinInliers': 5,  # Riduce la soglia minima per gli inliers
    'Odometer/MaxUpdateError': 0.5,  # Aumenta l'errore massimo per l'aggiornamento (più basso  -> più preciso)
    'Odometer/UpdateMaxFeatures': 200,  # Aumenta il numero massimo di feature usate per l'aggiornamento
    'Odometer/Reset': True,  # Abilita il reset automatico dell'odometria in caso di errore
    'publish_null_when_lost': False,    # non pubblica /odom se non riceve feature 
    #'wait_for_transform' : False,
    'publish_tf': True,                    
    #'publish_null_when_lost': False,       
    #'guess_frame_id': 'odom',   
    #'guess_min_translation': 0.01,      
    #'guess_min_rotation': 0.01,           
    #'wait_for_transform': False,          

    }]

    # use color camera 
    remappings_rgbd=[
        #('imu', '/imu/data'),
        ('rgb/image', '/camera/image_raw'),
        ('rgb/camera_info', '/camera/camera_info'),
        ('depth/image', '/camera/depth/image_raw'),
        ('odom','odom_camera')] 

    rtabmap_camera_node = TimerAction (
        period=3.0,
        actions=[Node(
            package='rtabmap_odom', executable='rgbd_odometry', output='screen',
            parameters=parameters_rgbd,
            remappings=remappings_rgbd),
        ]
    )


    parameters_icp=[{
        'frame_id':'base_link',
        'subscribe_depth':True,
        'subscribe_scan_cloud':False, 
        'scan_cloud_max_points': 5000,  # Puoi aumentare questo valore se vuoi più punti per il rilevamento
        'scan_range_max': 5.0,   # 5 metri come distanza massima di rilevamento
        'scan_range_min': 0.05,   # Permette di rilevare oggetti a 50 cm di distanza o più
        'subscribe_scan':True,         
        'subscribe_rgbd':False,
        'subscribe_rgb':True,
        'approx_sync':True,
        'use_sim_time':True,
        'publish_tf':True,
        'odom_frame_id':'odom',
        'odom_topic':'odom_lidar',   # nome topic /odom -> /odom_lidar
        'queue_size': 10,
        'map_always_update': True,
        'map_empty_ray_tracing': True,     # Abilita il tracciamento di raggi vuoti
        'publish_null_when_lost': False,    # non pubblica /odom se non riceve feature 
        'guess_min_translation': 0.1,  # 10 cm
        'guess_min_rotation': 0.1,  # 0.1 rad (più sensibile)
        'Odom/ResetCountdown': '1',     #You can set Odom/ResetCountdown parameter to 1 to force an automatic reset of odometry from latest pose.

          }]

    remappings_icp=[
        ('rgb/image', '/camera/image_raw'),
        ('rgb/camera_info', '/camera/camera_info'),
        ('depth/image', '/camera/depth/image_raw'),
        ('scan', '/lidar' ),
        ('odom','odom_lidar')]

    rtabmap_lidar_node = TimerAction (
        period=3.0,
        actions=[Node(
            package='rtabmap_odom', executable='icp_odometry', output='screen',
            parameters=parameters_icp,
            #node_namespace='rtabmap',
            #arguments=['-d  --uinfo ' ], #--uinfo --Icp/Strategy 0
            remappings=remappings_icp),
        ]
        )

# per fare ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 camera_link mini2/worldd/rgb_camera
    tf_camera = Node(
            package='tf2_ros',  
            executable='static_transform_publisher', 
            name='camera_staticTF', 
            output='log',  
            arguments=['0.0', '0.0', '0.0', '0.0', '0.0', '0.0', 'camera_link', 'mini2/worldd/rgb_camera'],  
            parameters=[{"use_sim_time": True}],
        )

    rtabmap_rviz = TimerAction (
        period=3.0,
        actions=[Node(
            package='rtabmap_viz', executable='rtabmap_viz', output='screen',
            parameters=parameters_rgbd,
            remappings=remappings_rgbd),
        ]
    )

    nodes = [
        #odom_tf,
        rtabmap_camera_node,
        #rtabmap_rviz,
        rtabmap_lidar_node,
        tf_camera,

    ]

  
    return LaunchDescription(nodes)