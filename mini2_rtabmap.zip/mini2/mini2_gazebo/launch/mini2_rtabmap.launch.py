
from launch import LaunchDescription
from launch.actions import  TimerAction
from launch_ros.actions import Node

import os


def generate_launch_description():

   
    # Fixing the odometry frame in the map
    odom_tf = Node(
        package='mini2_gazebo',
        executable='dynamic_tf_publisher',
        name='odom_tf'
        )
    

    parameters_rgbd=[{
    # 'frame_id':'camera_link',
    'frame_id':'base_link',
    'odom_frame_id':'odom',
    'use_sim_time':True,
    'subscribe_depth':True,
    'subscribe_odom_info':True,
    'approx_sync':True,
    #'qos_image':qos,
    #'qos_imu':qos,
    #'wait_imu_to_init':False
    #'wait_for_transform' : True,
    #'wait_for_transform_duration' : 0.200000,
    #'publish_tf' : True,
    #'Odom/ResetCountdown' : 1,
    # 'Odometer/MinInliers' : 0,
    # 'Odometer/MaxUpdateError': 0.5,
    # 'Odometer/UpdateMaxFeatures': 100,
    #'Odometer/Reset': False,
    'publish_null_when_lost': False,
    #'wait_for_transform' : False,
    'publish_tf': True,                    # Pubblica il TF dal /odom a /base_link
    #'publish_null_when_lost': False,       # Non pubblica un "null transform", mantieni l'odometria corrente
    #'guess_frame_id': 'odom',   # Usa il frame "odom_combined" come punto di riferimento per l'odometria
    #'guess_min_translation': 0.01,        # Imposta una piccola soglia per la traslazione (1 cm)
    #'guess_min_rotation': 0.01,           # Imposta una piccola soglia per la rotazione (0.01 rad)
    #'wait_for_transform': False,          # Non aspettare per il TF, continua con l'odometria disponibile

    }]

    # use color camera 
    remappings_rgbd=[
        #('imu', '/imu/data'),
        ('rgb/image', '/camera/image_raw'),
        ('rgb/camera_info', '/camera/camera_info'),
        ('depth/image', '/camera/depth/image_raw')] 

    rtabmap_camera_node = TimerAction (
        period=3.0,
        actions=[Node(
            package='rtabmap_odom', executable='rgbd_odometry', output='screen',
            parameters=parameters_rgbd,
            remappings=remappings_rgbd),
        ]
    )


    parameters_icp=[{
        'frame_id':'base_link',
        'subscribe_depth':True,
        'subscribe_scan_cloud':False, 
        'scan_cloud_max_points': 500,
        'scan_range_max': 3.0,
        'scan_range_min': 0.2,
        'subscribe_scan':True,         
        'subscribe_rgbd':False,
        'subscribe_rgb':True,
        'approx_sync':True,
        'use_sim_time':True,
        'publish_tf':True,
        'odom_frame_id':'odom',
        'odom_topic':'odom',
        'queue_size': 3,
        'map_always_update': True,
        'map_empty_ray_tracing': True,
          }]

    remappings_icp=[
        ('rgb/image', '/camera/image_raw'),
        ('rgb/camera_info', '/camera/camera_info'),
        ('depth/image', '/camera/depth/image_raw'),
        ('scan', '/lidar' )]

    rtabmap_lidar_node = TimerAction (
        period=3.0,
        actions=[Node(
            package='rtabmap_odom', executable='icp_odometry', output='screen',
            parameters=parameters_icp,
            #node_namespace='rtabmap',
            #arguments=['-d  --uinfo ' ], #--uinfo --Icp/Strategy 0
            remappings=remappings_icp),
        ]
        )

# per fare ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 camera_link mini2/worldd/rgb_camera
    tf_camera = Node(
            package='tf2_ros',  
            executable='static_transform_publisher', 
            name='camera_staticTF', 
            output='log',  
            arguments=['0.0', '0.0', '0.0', '0.0', '0.0', '0.0', 'camera_link', 'mini2/worldd/rgb_camera'],  
            parameters=[{"use_sim_time": True}],
        ),

    rtabmap_rviz = TimerAction (
        period=3.0,
        actions=[Node(
            package='rtabmap_viz', executable='rtabmap_viz', output='screen',
            parameters=parameters_rgbd,
            remappings=remappings_rgbd),
        ]
    )

    nodes = [
        #odom_tf,
        #rtabmap_camera_node,
        #rtabmap_rviz,
        rtabmap_lidar_node,

    ]

  
    return LaunchDescription(nodes)