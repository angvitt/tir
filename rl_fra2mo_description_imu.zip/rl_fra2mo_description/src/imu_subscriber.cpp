#include <memory>
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/imu.hpp"
#include "geometry_msgs/msg/twist.hpp"

using std::placeholders::_1;

class ImuSubscriber : public rclcpp::Node
{
public:
  ImuSubscriber()
  : Node("imu_subscriber"), dt_(0.02), freq_taglio(40.0), g(9.806598843135166)
  {


    TC = 1/(2*3.14159*freq_taglio);

    alpha = dt_ / (TC + dt_);

    curr_acc_x_ = curr_acc_y_ = curr_acc_z_ = 0.0;
    curr_vel_x_ = curr_vel_y_ = curr_vel_z_ = 0.0;

    velocity_publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("demo/linear_velocity", 10);

    imu_subscription_ = this->create_subscription<sensor_msgs::msg::Imu>(
      "demo/imu", 10, std::bind(&ImuSubscriber::imu_callback, this, _1));
  
  }

private:
  void imu_callback(const sensor_msgs::msg::Imu::SharedPtr msg)
  {

    curr_acc_x_ = msg->linear_acceleration.x;
    curr_acc_y_ = msg->linear_acceleration.y;
    curr_acc_z_ = msg->linear_acceleration.z; //+ 9.806598843135166;

    filtered_acc_x_ = (1-alpha)*filtered_acc_x_ + alpha * curr_acc_x_;
    filtered_acc_y_ = (1-alpha)*filtered_acc_y_ + alpha * curr_acc_y_;
    filtered_acc_z_ = (1-alpha)*filtered_acc_z_ + alpha * curr_acc_z_ + g;


    double vel_x = curr_vel_x_ + dt_*filtered_acc_x_;
    double vel_y = curr_vel_y_ + dt_*filtered_acc_y_;
    double vel_z = curr_vel_z_ + dt_*filtered_acc_z_;

    RCLCPP_INFO(this->get_logger(), "Lin accel [x: %.3f, y: %.3f, z: %.3f] | Lin vel [x: %.3f, y: %.3f, z: %.3f]",
                curr_acc_x_, curr_acc_y_, curr_acc_z_,
                vel_x, vel_y, vel_z);

    RCLCPP_INFO(this->get_logger(), "alpha: %.3f]",
    alpha);

    curr_vel_x_ = vel_x;
    curr_vel_y_ = vel_y;
    curr_vel_z_ = vel_z;

    // Crea il messaggio di velocità lineare da pubblicare
    geometry_msgs::msg::Twist velocity_msg;
    velocity_msg.linear.x = vel_x;
    velocity_msg.linear.y = vel_y;
    velocity_msg.linear.z = vel_z;

    // Pubblica il messaggio
    velocity_publisher_->publish(velocity_msg);

  }

  const double dt_;
  
  
  const double freq_taglio, g;
  double TC, alpha; 
  double filtered_acc_x_, filtered_acc_y_, filtered_acc_z_;


  double curr_acc_x_, curr_acc_y_, curr_acc_z_;
  double curr_vel_x_, curr_vel_y_, curr_vel_z_;


  rclcpp::Subscription<sensor_msgs::msg::Imu>::SharedPtr imu_subscription_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr velocity_publisher_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ImuSubscriber>());
  rclcpp::shutdown();
  return 0;
}

// freq_taglio = 100;

// TC = 1/(2*3.14159*freq_taglio)

// alpha = dt_ / (TC + dt_)

// filtered = (1-alpha) filtered + alpha * input



// timestep = 0.02
// private acc corrente e precedente
//e inizializzi a zero nel costruttore classe
// acc corrente = subscriber acc ang corrente
// corrente = (corrente - precedente) / timestep
// precedente = corrente