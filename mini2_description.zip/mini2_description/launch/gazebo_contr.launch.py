import os

from ament_index_python.packages import get_package_share_path

from launch.actions import RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, SetEnvironmentVariable
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
)

def generate_launch_description():

    # Percorsi ai file
    mini2_path = get_package_share_path('mini2_description')
    default_model_path = mini2_path / 'urdf/mini2_description.urdf'
    
    models_path = os.path.join(get_package_share_directory('mini2_description'), 'models')
    world_file = os.path.join(mini2_path, "worlds", "leonardo_race_field.sdf")


    urdf = os.path.join(
        get_package_share_path('mini2_description'),
        'urdf', 'mini2_description.urdf')
    with open(urdf, 'r') as infp:
        robot_desc = infp.read()

    robot_description = {"robot_description": ParameterValue(robot_desc, value_type=str)}
    
    # use_sim_time_arg = DeclareLaunchArgument(
    #     'use_sim_time', default_value='true', description='Use simulation/Gazebo clock')


    # Node robot_state_publisher
    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[robot_description,
                    {"use_sim_time": True}],
            
            
    )

    # Nodo joint_state_publisher
    joint_state_publisher_node = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        parameters=[{"use_sim_time": True}]
    )


    # load_joint_state_controller = ExecuteProcess(
    #     cmd=['ros2', 'control', 'load_controller', '--set-state', 'active',
    #          'joint_state_broadcaster'],
    #     output='screen'
    # )

    # load_joint_trajectory_controller = ExecuteProcess(
    #     cmd=['ros2', 'control', 'load_controller', '--set-state', 'active',
    #          'gazebo_joint_controller'],
    #     output='screen'
    # )

    # robot_controllers = PathJoinSubstitution(
    #     [
    #         FindPackageShare('mini2_description'),
    #         'config',
    #         'mini2_joint_controller.yaml',
    #     ]
    # )

    robot_controllers = os.path.join(
        get_package_share_directory('mini2_description'),
            'config',
            'mini2_joint_controller.yaml'
    )
    with open(robot_controllers, 'r') as infp:
        robot_contr = infp.read()
    

    robot_controller = {"robot_controllers": ParameterValue(robot_contr, value_type=str)}

    control_node = Node(
        package="controller_manager",
        executable="ros2_control_node",
        parameters=[robot_controllers],
        output="screen",
    )



    # load_controller = Node( 
    #     package="controller_manager", 
    #     executable="spawner", 
    #     arguments=["joint_trajectory_controller", "--controller-manager", "/controller_manager"], 
    #     )

    joint_state_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster'],
        output='screen'
    )

    mini2_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=[
            'joint_trajectory_controller',
            '--param-file',
            robot_controllers
            ],
            output='screen'
    )

    declared_arguments = []
    declared_arguments.append(DeclareLaunchArgument('gz_args', default_value=world_file,
                              description='path to world file'),)

    
    # Gazebo simulation launch description
    gazebo_ignition = IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                [PathJoinSubstitution([FindPackageShare('ros_gz_sim'),
                                    'launch',
                                    'gz_sim.launch.py'])]),
            launch_arguments={'gz_args': LaunchConfiguration('gz_args')}.items()
    )

    position = [0.0, 0.0, 0.100]

    # Define a Node to spawn the robot in the Gazebo simulation
    ignition_spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        output='screen',
        arguments=['-topic', 'robot_description',
                   '-name', 'mini2_description',
                   '-allow_renaming', 'true',
                    "-x", str(position[0]),
                    "-y", str(position[1]),
                    "-z", str(position[2]),]
    )

    # Bridge
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'],
        output='screen'
    )


    # odom_tf = Node(
    #     package='mini2_description',
    #     executable='dynamic_tf_publisher',
    #     name='odom_tf',
    #     parameters=[{"use_sim_time": True}]
    # )

    # laser_id_link_tf = Node(package='tf2_ros',
    #                  executable='static_transform_publisher',
    #                  name='lidar_staticTF',
    #                  output='log',
    #                  arguments=['0.0', '0.0', '0.0', '0.0', '0.0', '0.0', 'laser_frame', 'fra2mo/base_footprint/laser_frame'],
    #                  parameters=[{"use_sim_time": True}]
    # )

    # robot_localization_node = Node(
    #    package='robot_localization',
    #    executable='ekf_node',    RegisterEventHandler(
        #     event_handler=OnProcessExit(
        #         target_action=ignition_spawn_entity,
        #         on_exit=[control_node],
        #     )
        # ),_node',
    #    output='screen',
    #    parameters=[os.path.join(get_package_share_directory('rl_fra2mo_description'), "config/ekf.yaml")]
    # )

    # ign_clock_bridge = Node(
    #     package="ros_gz_bridge",
    #     executable="parameter_bridge",
    #     name="ros_gz_bridge",
    #     arguments=["/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock"],
    #     remappings=[
    #         ("/tf", "tf"),
    #         ("/tf_static", "tf_static"),
    #     ],
    #     output="screen",
    #     namespace="fra2mo"
    # )
 
    # ign = [gazebo_ignition, gz_spawn_entity]
    # nodes_to_start = [robot_state_publisher_node, joint_state_publisher_node, *ign, bridge, 
    #                   odom_tf, laser_id_link_tf, ign_clock_bridge]

    
    RegisterEventHandler(
            event_handler=OnProcessExit(
                target_action=ignition_spawn_entity,
                on_exit=[joint_state_broadcaster_spawner],
            )
        ),
    RegisterEventHandler(
            event_handler=OnProcessExit(
                target_action=joint_state_broadcaster_spawner,
                on_exit=[mini2_controller_spawner],
            )
        )

    ign = [gazebo_ignition, ignition_spawn_entity]
    nodes_to_start = [robot_state_publisher_node, joint_state_publisher_node, bridge,
                        *ign]



    return LaunchDescription([SetEnvironmentVariable(name="GZ_SIM_RESOURCE_PATH", value = models_path + ':' + os.environ.get('GZ_SIM_RESOURCE_PATH', ''))] + declared_arguments + nodes_to_start)
