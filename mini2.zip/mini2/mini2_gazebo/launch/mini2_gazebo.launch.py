from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare


 

def generate_launch_description():
    

    other_launch_file_mini2_world = PathJoinSubstitution(
        [FindPackageShare("mini2_gazebo"), "launch", "mini2_world.launch.py"]
    )

    
    include_other_launch_mini2_world= IncludeLaunchDescription(
        PythonLaunchDescriptionSource(other_launch_file_mini2_world)
    )

    other_launch_file_mini2_control= PathJoinSubstitution(
        [FindPackageShare("mini2_control"), "launch", "mini2_control.launch.py"]
    )

    
    include_other_launch_mini2_control = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(other_launch_file_mini2_control)
    )

    
    return LaunchDescription([
        include_other_launch_mini2_world, 
        include_other_launch_mini2_control

    ])
