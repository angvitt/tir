
from launch import LaunchDescription
from launch.actions import  TimerAction
from launch_ros.actions import Node

import os


def generate_launch_description():

   
    # Fixing the odometry frame in the map
    odom_tf = Node(
        package='mini2_gazebo',
        executable='dynamic_tf_publisher',
        name='odom_tf'
        )
    

    parameters_rgbd=[{
    # 'frame_id':'camera_link',
    'frame_id': 'base_link',
    'odom_frame_id': 'odom',
    'odom_topic': 'odom_camera',
    'use_sim_time': True,
    'subscribe_depth': True,
    'subscribe_odom_info': True,
    'approx_sync': True,
    'RGBD/MaxFeatures': '2000',
    'RGBD/MinInliers': '8',
    'RGBD/LinearUpdate': '0.1',
    'RGBD/AngularUpdate': '0.1',
    'Vis/MinInliers': '8',
    'Rtabmap/DetectLoop': True,
    'Rtabmap/LoopThr': '0.3',
    'Mem/IncrementalMemory': True,
    'Rtabmap/TimeThr': '0.2',
    'Mem/OptimizeFromGraphEnd': True,
    'Odom/ResetCountdown': '5',  # Reset ogni 5 frame se l'odometria è instabile
    'Odom/ResetOnLostFeatures': True,  # Reset se le feature vengono perse
    'Odom/MaxCorrectionDist': '1.0',  # Limita le correzioni a 1 metro
    'Rtabmap/ForceOdomReset': False,  # Non forzare il reset dell'odometria ogni ciclo


    }]

    # use color camera 
    remappings_rgbd=[
        #('imu', '/imu/data'),
        ('rgb/image', '/camera/image_raw'),
        ('rgb/camera_info', '/camera/camera_info'),
        ('depth/image', '/camera/depth/image_raw'),
        ('odom','odom_camera')] 

    rtabmap_camera_node = TimerAction (
        period=3.0,
        actions=[Node(
            package='rtabmap_odom', executable='rgbd_odometry', output='screen',
            parameters=parameters_rgbd,
            remappings=remappings_rgbd),
        ]
    )


    parameters_icp=[{
        'frame_id':'base_link',
        'map_frame_id' : 'map',
        'subscribe_depth':True,
        'subscribe_scan_cloud':False, 
        'scan_cloud_max_points': 5000,  # Puoi aumentare questo valore se vuoi più punti per il rilevamento
        'scan_range_max': 5.0,   # 5 metri come distanza massima di rilevamento
        'scan_range_min': 0.05,   # Permette di rilevare oggetti a 50 cm di distanza o più
        'subscribe_scan':True,         
        'subscribe_rgbd':False,
        'subscribe_rgb':True,
        'approx_sync':True,
        'use_sim_time':True,
        'publish_tf':False,       # messo a false per non avere warning tf_old_data   ## Publish TF from /odom to /base_link. 
        'odom_frame_id':'odom',
        'odom_topic':'odom_lidar',   # nome topic /odom -> /odom_lidar
        'queue_size': 10,
        'map_always_update': True,
        'map_empty_ray_tracing': True,     # Abilita il tracciamento di raggi vuoti
        'publish_null_when_lost': False,    # non pubblica /odom se non riceve feature 
        'guess_min_translation': 0.1,  # 10 cm
        'guess_min_rotation': 0.1,  # 0.1 rad (più sensibile)
        'Odom/ResetCountdown': '1',     #You can set Odom/ResetCountdown parameter to 1 to force an automatic reset of odometry from latest pose.
        'use_sim_time': True,
          }]

    remappings_icp=[
        ('rgb/image', '/camera/image_raw'),
        ('rgb/camera_info', '/camera/camera_info'),
        ('depth/image', '/camera/depth/image_raw'),
        ('scan', '/lidar' ),
        ('odom','odom_lidar')]

    rtabmap_lidar_node = TimerAction (
        period=3.0,
        actions=[Node(
            package='rtabmap_odom', executable='icp_odometry', output='screen',
            parameters=parameters_icp,
            #node_namespace='rtabmap',
            #arguments=['-d  --uinfo ' ], #--uinfo --Icp/Strategy 0
            remappings=remappings_icp),
        ]
        )

# per fare ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0 camera_link mini2/worldd/rgb_camera
    tf_camera = Node(
            package='tf2_ros',  
            executable='static_transform_publisher', 
            name='camera_staticTF', 
            output='log',  
            arguments=['0.0', '0.0', '0.0', '0.0', '0.0', '0.0', 'camera_link', 'mini2/base_footprint/rgb_camera'],  
            parameters=[{"use_sim_time": True}],
        )

    rtabmap_rviz = TimerAction (
        period=3.0,
        actions=[Node(
            package='rtabmap_viz', executable='rtabmap_viz', output='screen',
            parameters=parameters_rgbd,
            remappings=remappings_rgbd),
        ]
    )

    nodes = [
        #odom_tf,
        #rtabmap_camera_node,
        #rtabmap_rviz,
        rtabmap_lidar_node,
        #tf_camera,

    ]

  
    return LaunchDescription(nodes)