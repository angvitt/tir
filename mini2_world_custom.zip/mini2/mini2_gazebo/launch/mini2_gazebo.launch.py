import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
)
from launch.actions import RegisterEventHandler
from launch.event_handlers import OnProcessExit

def generate_launch_description():
    

# Include the mini2_world launch file
    mini2_world = IncludeLaunchDescription(
      PythonLaunchDescriptionSource([os.path.join(
         get_package_share_directory('mini2_gazebo'), 'launch'),
         '/mini2_world.launch.py'])
      )
    
    # Include the mini2_control launch file after mini2_world
    mini2_control = IncludeLaunchDescription(
      PythonLaunchDescriptionSource([os.path.join(
         get_package_share_directory('mini2_control'), 'launch'),
         '/mini2_control.launch.py'])
      )
    
    # Include the mini2_rtabmap launch file after mini2_control
    mini2_rtabmap = IncludeLaunchDescription(
      PythonLaunchDescriptionSource([os.path.join(
         get_package_share_directory('mini2_gazebo'), 'launch'),
         '/mini2_rtabmap.launch.py'])
      )

    # Include the mini2_slam launch file after mini2_control
    mini2_slam = IncludeLaunchDescription(
      PythonLaunchDescriptionSource([os.path.join(
         get_package_share_directory('mini2_gazebo'), 'launch'),
         '/mini2_slam.launch.py'])
      )

    nodes_to_start = [
        mini2_world,
        mini2_control,
        #mini2_rtabmap,
        #mini2_slam,
    ]

    return LaunchDescription(nodes_to_start) 
