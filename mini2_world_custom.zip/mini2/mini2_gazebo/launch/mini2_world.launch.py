
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument, RegisterEventHandler, SetEnvironmentVariable, TimerAction
from launch.conditions import IfCondition, UnlessCondition
from launch.event_handlers import OnProcessExit, OnProcessStart
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, FindExecutable, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory
from ament_index_python import get_package_prefix
import os


def generate_launch_description():
    declared_arguments = []
   

    link_description_path = get_package_share_directory('mini2_description')
    desc_path_xacro=os.path.join(link_description_path, "urdf", "mini2.urdf.xacro")

    r_d_x = {"robot_description": ParameterValue(Command(['xacro ', desc_path_xacro]),value_type=str)}


    # robot_state_publisher
    robot_state_pub_node = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        parameters=[r_d_x, {"use_sim_time": True}],
        output="screen"
    )
   
    # models_path = os.path.join(get_package_share_directory('mini2_description'), 'models')
    # world_file = os.path.join(get_package_share_directory('mini2_description'), "worlds", "empty_custom.sdf")


    # Percorso mondo e modelli
    world_file = os.path.join(link_description_path, 'worlds', 'leonardo_race_field.sdf')
    models_path = os.path.join(link_description_path, 'models')


    # Dichiarazione argomento per Gazebo
    declared_arguments = [
        DeclareLaunchArgument('gz_args', default_value='-r -v 1 ' + world_file,
                              description='Arguments for gz_sim')
    ]

    #declared_arguments.append(DeclareLaunchArgument('gz_args', default_value='-r -v 1 ' + world_file,
    #                           description='Arguments for gz_sim'),)

    #declared_arguments.append(DeclareLaunchArgument('gz_args', default_value='-r -v 1 empty.sdf',
    #                          description='Arguments for gz_sim'),)
    
    gazebo_ignition = IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                [PathJoinSubstitution([FindPackageShare('ros_gz_sim'),
                                    'launch',
                                    'gz_sim.launch.py'])]),
            launch_arguments={'gz_args': LaunchConfiguration('gz_args')}.items()
    )

    position = [0.0, 0.0, 0.100]

    gz_spawn_entity = Node(
        package="ros_gz_sim",
        executable="create",
        arguments=[
            "-topic", "/robot_description",
            "-name", "mini2",
            "-allow_renaming", "true"
            "-x", str(position[0]),
            "-y", str(position[1]),
            "-z", str(position[2]),],
        output="screen"
    )
 
    ign = [gazebo_ignition, gz_spawn_entity]


    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/lidar@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
                   '/lidar/points@sensor_msgs/msg/PointCloud2[ignition.msgs.PointCloudPacked',
                   
                   '/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock',

                   '/demo/imu@sensor_msgs/msg/Imu[ignition.msgs.IMU',

                   '/cmd_vel@geometry_msgs/msg/Twist@ignition.msgs.Twist',
                   '/camera/image_raw@sensor_msgs/msg/Image[ignition.msgs.Image',  # Immagine RGB
                   '/camera/camera_info@sensor_msgs/msg/CameraInfo[ignition.msgs.CameraInfo',  # Info fotocamera
                   '/camera/depth/image_raw@sensor_msgs/msg/Image[ignition.msgs.Image',  # Immagine profondità
                   '/camera/depth/camera_info@sensor_msgs/msg/CameraInfo[ignition.msgs.CameraInfo',  # Info fotocamera profondità
                   '/camera/points@sensor_msgs/msg/PointCloud2[ignition.msgs.PointCloudPacked',  # Nuvola di punti (se necessario)
                   #'/depth/image_raw/points@sensor_msgs/msg/PointCloud2[ignition.msgs.PointCloudPacked',
               

                #    '/model/mini2/odometry@nav_msgs/msg/Odometry@ignition.msgs.Odometry',
                #    '/model/mini2/tf@tf2_msgs/msg/TFMessage@ignition.msgs.Pose_V',

                   #'/camera@sensor_msgs/msg/Image@ignition.msgs.Image', 
                   #'/camera_info@sensor_msgs/msg/CameraInfo@ignition.msgs.CameraInfo',
                   #'/depth_camera/points@sensor_msgs/msg/PointCloud2@gz.msgs.PointCloudPacked',
                   #'/depth_camera@sensor_msgs/msg/Image@ignition.msgs.Image',
                #    '/depth_camera/image_raw@sensor_msgs/msg/Image@ignition.msgs.Image',
                #    '/depth_camera/camera_info@sensor_msgs/msg/CameraInfo@ignition.msgs.CameraInfo',
                #    '/depth/points@sensor_msgs/msg/PointCloud2@ignition.msgs.PointCloudPacked'
                   ],
                   #'/lidar/points@sensor_msgs/msg/PointCloud2[ignition.msgs.PointCloudPacked'], 
        output='screen'
    )

    laser_id_link_tf = Node(package='tf2_ros',
                     executable='static_transform_publisher',
                     name='lidar_staticTF',
                     output='log',
                     arguments=['0.0', '0.0', '0.0', '0.0', '0.0', '0.0', 'laser_frame', 'mini2/base_footprint/laser_frame'],
                     parameters=[{"use_sim_time": True}]
    )
    
    # Fixing the odometry frame in the map
    odom_tf = Node(
        package='mini2_gazebo',
        executable='dynamic_tf_publisher',
        name='odom_tf',
        parameters=[{"use_sim_time": True}]
        )
    
    robot_localization_node = Node(
       package='robot_localization',
       executable='ekf_node',
       name='ekf_filter_node',
       output='screen',
       parameters=[os.path.join(get_package_share_directory('mini2_description'), "config/ekf.yaml"), {"use_sim_time": True}]
    )



    # rtabmap_rviz = TimerAction (
    #     period=2.0,
    #     actions=[Node(
    #         package='rtabmap_viz', executable='rtabmap_viz', output='screen',
    #         parameters=parameterss,
    #         remappings=remappingss),
    #     ]
    #)

    ign_clock_bridge = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        name="ros_gz_bridge",
        arguments=["/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock"],
        remappings=[
            ("/tf", "tf"),
            ("/tf_static", "tf_static"),
        ],
        output="screen",
        namespace="mini2"
    )


   # Set the environment variable before returning
        # Set env var per GZ_SIM_RESOURCE_PATH
    set_env_var = SetEnvironmentVariable(
        name="GZ_SIM_RESOURCE_PATH",
        value=models_path + ':' + os.environ.get('GZ_SIM_RESOURCE_PATH', '')
    )


    nodes = [
        set_env_var,
        *declared_arguments,
        robot_state_pub_node,
        *ign,
        bridge,
        #laser_id_link_tf,
        #odom_tf,
        robot_localization_node,

        #tf_camera,
        #rtabmap_rviz,
        
        #ign_clock_bridge,

    ]


    #return LaunchDescription([set_env_var] + declared_arguments + nodes)

    return LaunchDescription(declared_arguments + nodes)