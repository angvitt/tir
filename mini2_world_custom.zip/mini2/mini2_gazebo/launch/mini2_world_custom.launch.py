from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, SetEnvironmentVariable
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution, Command
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare
from launch.launch_description_sources import PythonLaunchDescriptionSource
import os

def generate_launch_description():
    mini2_path = FindPackageShare('mini2_description').find('mini2_description')

    # Percorso mondo e modelli
    world_file = os.path.join(mini2_path, 'worlds', 'leonardo_race_field.sdf')
    models_path = os.path.join(mini2_path, 'models')

    # Percorso xacro URDF
    xacro_file = os.path.join(mini2_path, 'urdf', 'mini2.urdf.xacro')

    # Dichiarazione argomento per Gazebo
    declared_arguments = [
        DeclareLaunchArgument('gz_args', default_value='-r -v 1 ' + world_file,
                              description='Arguments for gz_sim')
    ]

    # Set env var per GZ_SIM_RESOURCE_PATH
    set_env_var = SetEnvironmentVariable(
        name="GZ_SIM_RESOURCE_PATH",
        value=models_path + ':' + os.environ.get('GZ_SIM_RESOURCE_PATH', '')
    )

    # Avvio di Gazebo
    gazebo_ignition = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('ros_gz_sim'),
                'launch',
                'gz_sim.launch.py'
            ])
        ]),
        launch_arguments={'gz_args': LaunchConfiguration('gz_args')}.items()
    )

    # Robot Description dal xacro
    robot_description = {
        "robot_description": ParameterValue(
            Command(["xacro ", xacro_file]), value_type=str
        )
    }

    # robot_state_publisher
    robot_state_pub_node = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        parameters=[robot_description, {"use_sim_time": True}],
        output="screen"
    )

    position = [0.0, 0.0, 0.100]

    # Spawn robot
    spawn_robot = Node(
        package="ros_gz_sim",
        executable="create",
        arguments=[
            "-topic", "/robot_description",
            "-name", "mini2",
            "-allow_renaming", "true"
            "-x", str(position[0]),
            "-y", str(position[1]),
            "-z", str(position[2]),],
        output="screen"
    )


    return LaunchDescription([
        set_env_var,
        *declared_arguments,
        gazebo_ignition,
        robot_state_pub_node,
        spawn_robot
    ])
