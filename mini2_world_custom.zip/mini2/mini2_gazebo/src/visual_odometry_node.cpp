#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/opencv.hpp>             
#include <opencv2/features2d.hpp>        
#include <opencv2/calib3d.hpp>           
#include <opencv2/highgui/highgui.hpp>  
#include <opencv2/core/core.hpp>         
#include <memory>                        


class VisualOdometryNode : public rclcpp::Node
{
public:
    VisualOdometryNode() : Node("visual_odometry_node")
    {
        // Inizializzazione della fotocamera e del bridge per convertire le immagini
        bridge_ = std::make_shared<cv_bridge::CvBridge>();
        prev_image_ = nullptr;
        prev_gray_ = nullptr;

        // Sottoscrizione al topic dell'immagine (presumendo il topic '/camera/image_raw')
        subscription_ = this->create_subscription<sensor_msgs::msg::Image>(
            "/camera/image_raw", 10,
            std::bind(&VisualOdometryNode::listener_callback, this, std::placeholders::_1));

        // Parametri per il rilevamento delle feature (ORB)
        orb_ = cv::ORB::create();

        // Parametri di stima del movimento (Odometry)
        prev_position_ = cv::Mat::zeros(3, 1, CV_32F);
    }

private:
    void listener_callback(const sensor_msgs::msg::Image::SharedPtr msg)
    {
        // Convertire il messaggio ROS2 in un'immagine OpenCV
        cv::Mat current_image = bridge_->imgmsg_to_cv2(*msg, "bgr8");

        // Convertire l'immagine corrente in scala di grigio
        cv::Mat current_gray;
        cv::cvtColor(current_image, current_gray, cv::COLOR_BGR2GRAY);

        if (prev_image_ != nullptr)
        {
            // Trova le keypoints e descrittori per l'immagine corrente
            std::vector<cv::KeyPoint> kp1, kp2;
            cv::Mat des1, des2;
            orb_->detectAndCompute(prev_gray_, cv::Mat(), kp1, des1);
            orb_->detectAndCompute(current_gray, cv::Mat(), kp2, des2);

            // Corrispondenze tra i descrittori usando BFMatcher
            cv::BFMatcher bf(cv::NORM_HAMMING, true);
            std::vector<cv::DMatch> matches;
            bf.match(des1, des2, matches);

            // Ordinare le corrispondenze per distanza
            std::sort(matches.begin(), matches.end());

            // Estrazione delle coordinate dei keypoint
            std::vector<cv::Point2f> src_pts, dst_pts;
            for (size_t i = 0; i < matches.size(); i++)
            {
                src_pts.push_back(kp1[matches[i].queryIdx].pt);
                dst_pts.push_back(kp2[matches[i].trainIdx].pt);
            }

            // Calcolare la trasformazione usando la funzione di epipolar geometry (stima del movimento)
            cv::Mat E = cv::findEssentialMat(src_pts, dst_pts, 1.0, cv::Point2d(current_image.cols / 2.0, current_image.rows / 2.0), cv::RANSAC, 0.999, 1.0);
            cv::Mat R, t;
            cv::recoverPose(E, src_pts, dst_pts, R, t, 1.0, cv::Point2d(current_image.cols / 2.0, current_image.rows / 2.0));

            // Aggiornare la posizione precedente
            prev_position_ = prev_position_ + t;
            RCLCPP_INFO(this->get_logger(), "Posizione stimata: [%f, %f, %f]", prev_position_.at<float>(0), prev_position_.at<float>(1), prev_position_.at<float>(2));
        }

        // Aggiornare l'immagine precedente
        prev_image_ = current_image;
        prev_gray_ = current_gray;
    }

    rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr subscription_;
    std::shared_ptr<cv_bridge::CvBridge> bridge_;
    cv::Mat prev_image_, prev_gray_;
    cv::Mat prev_position_;
    cv::Ptr<cv::ORB> orb_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<VisualOdometryNode>());
    rclcpp::shutdown();
    return 0;
}
